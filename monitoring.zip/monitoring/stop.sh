#!/bin/bash
set -x

docker-compose down
