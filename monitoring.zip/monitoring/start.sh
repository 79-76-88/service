#!/bin/bash
set -x

mkdir -p prometheus/durable loki/durable
chmod a+w prometheus/durable loki/durable

docker-compose up -d
